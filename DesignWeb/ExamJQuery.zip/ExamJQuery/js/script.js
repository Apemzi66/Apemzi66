$(document).ready(function () {
    $("#court").hide();
    $("#long").hide();

    $("#mot").keyup(function () {
        var mot = $('#mot').val().length;
        if (mot>12) {
            $("#long").show();
            $("#court").hide();
        }
        else if (mot<3){
            $("#court").show();
            $("#long").hide();
        }
        else {
            $("#long").hide();
            $("#court").hide();
        }
    });
});
$("#mot").onkeyup(function() {
    var value = $("#mot").val();
    $("#bruh").text(value);
});


